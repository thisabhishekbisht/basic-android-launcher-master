# Basic Android Launcher

Android launcher created for college project.

# How to run

Open project and run in emulator or connect android phone to run on it.

# Screenshots

Screenshots are provided in screenshots folder of project.

# Why

This project was only created for college academics.
