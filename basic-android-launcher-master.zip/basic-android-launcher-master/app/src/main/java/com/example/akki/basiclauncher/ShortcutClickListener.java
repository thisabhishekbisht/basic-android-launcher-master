package com.example.akki.basiclauncher;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.view.View;



public class ShortcutClickListener implements View.OnClickListener {
    Context mContext;

    public  ShortcutClickListener(Context c) {
        mContext = c;
    }

    @Override
    public void onClick(View v) {
        Intent data;
        data = (Intent) v.getTag();

        mContext.startActivity(data);
    }
}
