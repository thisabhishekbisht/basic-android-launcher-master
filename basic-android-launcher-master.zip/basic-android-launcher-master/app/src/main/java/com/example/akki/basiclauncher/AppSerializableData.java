package com.example.akki.basiclauncher;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


public class AppSerializableData implements Serializable {
    List<Pac> apps = new ArrayList<Pac>();
}
