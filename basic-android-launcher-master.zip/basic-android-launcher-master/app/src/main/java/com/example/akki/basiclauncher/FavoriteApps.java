package com.example.akki.basiclauncher;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


public class FavoriteApps implements Serializable {
    List<FavPac> apps = new ArrayList<FavPac>();
}
